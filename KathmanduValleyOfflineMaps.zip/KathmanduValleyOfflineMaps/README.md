# Kathmandu Valley Offline Maps

Real Android app for an offline map covering Kathmandu, Lalitpur (Patan) and Bhaktapur.

## What's new in this version
- **Verified landmark database**: 8 major sites (Kathmandu/Patan/Bhaktapur Durbar Squares,
  Swayambhunath, Boudhanath, Pashupatinath, Thamel, Tribhuvan International Airport) with
  coordinates cross-checked against Wikipedia/official references at build time (see table below).
- **Working search**: typing a name or city now actually flies the map to that place and drops
  a labeled pin, instead of just showing a toast.
- **Download progress bar** with live percent + resource counts, not just toasts.
- **Persistent offline state**: on launch the app checks `OfflineManager.listOfflineRegions` so it
  knows whether the Valley is already downloaded, and shows a **Delete Offline Data** option.
- **Offline-first messaging**: if you open the app with no internet and no completed download yet,
  it tells you plainly instead of showing a blank map.
- **Required OSM/OpenFreeMap attribution** shown on-screen (ODbL requires this for production use).
- Fixed a marker-stacking bug (GPS "You are here" and search pins now replace themselves instead
  of piling up), and fixed the Material3 theme to use `colorPrimary` instead of the unused legacy
  `colorAccent`-only setup.

## Landmark coordinates and sources
| Place | City | Lat | Lng | Source |
|---|---|---|---|---|
| Kathmandu Durbar Square | Kathmandu | 27.7040 | 85.3070 | Wikipedia (Nautalle Durbar / Hanuman Dhoka) |
| Patan Durbar Square | Lalitpur | 27.6734 | 85.3250 | Wikipedia |
| Bhaktapur Durbar Square | Bhaktapur | 27.6720 | 85.4281 | Wikipedia |
| Swayambhunath | Kathmandu | 27.7150 | 85.2900 | Wikipedia |
| Boudhanath Stupa | Kathmandu | 27.7214 | 85.3619 | Wikipedia |
| Pashupatinath Temple | Kathmandu | 27.7097 | 85.3486 | Wikipedia |
| Thamel | Kathmandu | 27.7091 | 85.3061 | latitude.to |
| Tribhuvan Intl. Airport (KTM) | Kathmandu | 27.6912 | 85.3553 | latitude.to |

## Honest limits (please read)
"100% accurate" is a high bar worth being precise about:
- The base map tiles are OpenStreetMap-derived (via OpenFreeMap). OSM is generally excellent for
  the Kathmandu Valley, but it's community-maintained, so small road/building changes can lag
  behind reality — the app can't guarantee the underlying map data is perfect, only that it's
  using the standard, well-maintained OSM pipeline.
- The 8 landmark pins are hand-verified against reference sources, but this is still a small,
  hand-picked list, not a full POI database. It's a real, correct starting point — not a
  substitute for something like a full OSM Nominatim/Overpass search index.
- There's no offline routing engine yet (no turn-by-turn directions); this is a map viewer +
  landmark search, not a navigation app.
- First map download still requires internet, by the nature of how offline map tiles work —
  there's no way to have offline data before it's ever been fetched once.

## Build
Open the folder in Android Studio with Android SDK 35 and JDK 17. Sync Gradle and run the `app`
configuration. Location permission is requested at runtime for the "My Location" button.

Map data attribution is now shown on-screen; review OpenFreeMap/OSM ODbL terms before any
commercial deployment.
